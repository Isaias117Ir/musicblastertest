package com.isaia.musicblaster;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
